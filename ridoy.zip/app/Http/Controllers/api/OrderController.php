<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;

class OrderController extends Controller
{
    //
}
